@extends('layouts.master')

@section('title',trans('app.centers.centers'))
@section('content')
    <section class="container">
        <div class="row">
  {{--    <h1 style="text-align: center; margin: 16.5%">{{trans('app.coming_soon')}}</h1> --}}       
 <img src="a.jpg" alt="Smiley face">         </div>
    </section>
@endsection
